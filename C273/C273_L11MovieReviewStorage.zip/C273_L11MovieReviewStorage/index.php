<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>View All Movie Reviews</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script src="js/jquery-3.5.1.min.js"></script> 
        <script src="js/bootstrap.min.js"></script> 
        <script src="js/index.js"></script>
    </head>
    <body>
            <?php include "navbar.php"; ?>
        <div class="container">
            <br/>
            <div id="contents"></div>
        </div>
    </body>
</html>
